<?php $__env->startSection("titulo"); ?>
    Dèco Enfant - Gracias por su compra
<?php $__env->stopSection(); ?>


<?php $__env->startSection("principal"); ?>
    <h1>Muchas gracias por su compra</h1>
      <a href="/history"> Ver historial de compra</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/thanks.blade.php ENDPATH**/ ?>