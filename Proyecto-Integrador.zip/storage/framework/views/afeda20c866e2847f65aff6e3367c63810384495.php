<?php $__env->startSection("titulo"); ?>
    Dèco Enfant - Productos
<?php $__env->stopSection(); ?>


<?php $__env->startSection("principal"); ?>

  <!-- PRODUCTOS ---------------------------------------------------------------------------------------------------------->
  <section class="container">
    
    <div class="text-center pt-4">
        <h2 class="my-0 mx-auto w-100 text-uppercase"><img src="/img/icon-paper-plane.png">  Productos</h2>
        <hr>
    </div>

    <div class="">
        <div class="d-flex flex-row justify-content-around">
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
            <a href="/productos/<?php echo e($cat->id); ?>" class="flex-item text-muted text-decoration-none" > <?php echo e($cat->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
        <hr>
        
    </div>

    
    <div class="row px-2">
        
        <!--- Generar Articulos ------------->
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        
        <article class="col-6 col-md-4 col-lg-3 p-1">
            <a href="/producto/<?php echo e($product->id); ?>">
                <img class="img-fluid img-thumbnail destacados-img"
                src=<?php echo e(url($product->thumbnail)); ?> alt=<?php echo e($product->name); ?>>
                
                <div class="d-flex flex-wrap align-items-center justify-content-between">
                    <div id="descrip-item" class="col-12 col-lg-8 d-flex align-items-center p-2"><a class="text-decoration-none text-dark" href="/producto/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a></div>
                    <div class="col-12 col-lg-4 p-1">
                        <a href="/producto/<?php echo e($product->id); ?>" id="btn-destacados" class="btn text-uppercase p-0 w-100 py-2">ver más
                        </a>
                    </div>
                </div>
            </a>
            <hr class="mr-2 w-85">
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
        
    </div>
   
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("links"); ?>
<div class="container"> 
    
        <div class="d-flex justify-content-center"><?php echo e($products->links()); ?></div>
    
</div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/products.blade.php ENDPATH**/ ?>