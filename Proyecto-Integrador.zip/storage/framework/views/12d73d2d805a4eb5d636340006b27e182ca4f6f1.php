<?php $__env->startSection("titulo"); ?>
    Dèco Enfant - Agregar color
<?php $__env->stopSection(); ?>


<?php $__env->startSection("principal"); ?>
  <form class="" action="/colores/add" method="post">
    <?php echo e(csrf_field()); ?>


    <div class="">
      <input type="hidden" name="id" value="<?php echo e(old("id")); ?>">
    </div>

    <div class="">
      <label for="name">Nombre:</label>
      <div class="col-md-offset-3 col-md-6">
        <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old("name")); ?>">
        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
    </div>

    <div class="">
      <input type="submit" name="" value="Agregar color">
    </div>

  </form>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/Coloradd.blade.php ENDPATH**/ ?>