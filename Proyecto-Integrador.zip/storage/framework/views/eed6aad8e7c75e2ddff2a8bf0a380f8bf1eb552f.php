<?php $__env->startSection("titulo"); ?>
Dèco Enfant - Detalle del carrito
<?php $__env->stopSection(); ?>

<?php $__env->startSection("principal"); ?>

<section class="container">
  
    
    <div class="container">
      <table id="cart" class="table table-hover table-condensed">
        <thead>
          <tr>
            <th style="width:50%">Producto</th>
            <th style="width:10%">Precio</th>
            <th style="width:8%">Cantidad</th>
            <th style="width:22%" class="text-center">Subtotal</th>
            <th style="width:10%"></th>
          </tr>
        </thead>
        <?php $__empty_1 = true; $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tbody>
          <tr>
            <td data-th="Product">
              <div class="row">
                <div class="col-sm-2 hidden-xs"><img src="<?php echo e($items->thumbnail); ?>" alt=<?php echo e($items->name); ?> class="img-fluid img-thumbnail"/></div>
                <div class="col-sm-10">
                  <h4 class="nomargin"><?php echo e($items->name); ?></h4>
                  <p><?php echo e($items->short_desc); ?></p>
                </div>
              </div>
            </td>
            <td data-th="Price"><?php echo e($items->price); ?></td>
            <td data-th="Quantity">
              <input type="number" class="form-control text-center" value="1">
            </td>
            <td data-th="Subtotal" class="text-center">1.99</td>
            <td class="actions" data-th="">
              <button class="btn btn-info btn-sm"><i class="fa fa-refresh"></i></button>
              <form class="" action="/cart/<?php echo e($items->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></button>
              </form>
              
            </td>
          </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Su carrito esta vacio</p>
        <?php endif; ?>
        
        <tfoot>
          <tr class="visible-xs">
            <td class="text-center"><strong>Total 1.99</strong></td>
          </tr>
          <tr>
            <td><a href="#" class="btn btn-warning"><i class="fa fa-angle-left"></i> Seguir Comprando</a></td>
            <td colspan="2" class="hidden-xs"></td>
            <td class="hidden-xs text-center"><strong>Total $1.99</strong></td>
            <td class="px-0">
              <?php if($cart->isNotEmpty()): ?>
                <a href="/cart/close" class="btn btn-success btn-block">Comprar <i class="fa fa-angle-right"></i></a>
              <?php endif; ?>
            </td>  
          </tr>
        </tfoot>
      </table>
    </div>
  </section>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/cart.blade.php ENDPATH**/ ?>