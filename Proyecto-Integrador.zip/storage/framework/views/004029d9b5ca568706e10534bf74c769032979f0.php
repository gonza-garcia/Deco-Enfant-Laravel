<?php $__env->startSection("titulo"); ?>
    Dèco Enfant - Detalle de categoria
<?php $__env->stopSection(); ?>


<?php $__env->startSection("principal"); ?>
  <h3>Detalle de categoria: <?php echo e($category->id); ?></h3>
  <p>Nombre categoria: <?php echo e($category->name); ?></p>
  <p>Categoria padre: <?php echo e($category->id_parent); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/category.blade.php ENDPATH**/ ?>