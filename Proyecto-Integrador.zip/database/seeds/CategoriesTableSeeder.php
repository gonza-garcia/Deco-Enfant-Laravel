<?php

use Illuminate\Database\Seeder;

class CategoriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //no es necesario este seeder, ya que SubcategoriesTableSeeder también crea las categorías principales en la base de datos
    }
}
