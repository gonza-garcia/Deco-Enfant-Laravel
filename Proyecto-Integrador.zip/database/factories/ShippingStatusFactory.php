<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Shipping_status;
use Faker\Generator as Faker;

$factory->define(Shipping_status::class, function (Faker $faker) {
    return [
          'name' => $faker->sentence(1),
    ];
});
