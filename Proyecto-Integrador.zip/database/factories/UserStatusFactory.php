<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\User_status;
use Faker\Generator as Faker;

$factory->define(User_status::class, function (Faker $faker) {
    return [
        'name' => $faker->sentence(1),
    ];
});
