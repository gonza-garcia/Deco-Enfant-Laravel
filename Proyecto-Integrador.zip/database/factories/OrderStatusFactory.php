<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Order_status;
use Faker\Generator as Faker;

$factory->define(Order_status::class, function (Faker $faker) {
    return [
          'name' => $faker->sentence(1),
    ];
});
