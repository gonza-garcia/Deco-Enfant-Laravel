<form action="" method="POST" enctype="multipart/form-data">
    <!-- ::::::::::::::::::::::FORM HEADER::::::::::::::::::::: -->
    <div class="modal-header">
        <h4 class="modal-title">Editar Orden</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    </div>

    <!-- ::::::::::::::::::::::FORM BODY::::::::::::::::::::::: -->
    <div class="modal-body">
                    <!-- Id (No editable) -->
        <div class="form-group">

        </div>

                    <!-- Number -->
        <div class="form-group">

        </div>

                    <!-- Product_qty -->
        <div class="form-group">

        </div>

                    <!-- Product_price_unit -->
        <div class="form-group">

        </div>

                    <!-- User_id (Foránea) -->
        <div class="form-group">

        </div>

                    <!-- Product_id (Foránea) -->
        <div class="form-group">

        </div>
                    <!-- Order_status_id (Foránea) -->
        <div class="form-group">

        </div>

                    <!-- Shipping_status_id (Foránea) -->
        <div class="form-group">

        </div>

                    <!-- Created_at -->
        <div class="form-group">

        </div>
                    <!-- Updated_at -->
        <div class="form-group">

        </div>

    </div>

    <!-- :::::::::::::::::::::FORM FOOTER:::::::::::::::::::::: -->
    <div class="form-group modal-footer">
        <button type="submit" class="btn btn-info" name="caller_form" value="edit_order_form">Editar</button>
        <button type="reset" class="btn btn-default" data-dismiss="modal">Cancelar</button>
    </div>
</form>
