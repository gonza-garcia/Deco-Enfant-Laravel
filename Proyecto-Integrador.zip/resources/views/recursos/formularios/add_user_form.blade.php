<form action="" method="POST" enctype="multipart/form-data">
    <!-- ::::::::::::::::::::::FORM HEADER::::::::::::::::::::: -->
    <div class="modal-header">
        <h4 class="modal-title">Agregar Usuario</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    </div>

    <!-- ::::::::::::::::::::::FORM BODY::::::::::::::::::::::: -->
    <div class="modal-body">
                    <!-- Id (No editable) -->
        <div class="form-group">

        </div>

                    <!-- User_name -->
        <div class="form-group">

        </div>

                    <!-- First_name -->
        <div class="form-group">

        </div>

                    <!-- Last_name -->
        <div class="form-group">

        </div>

                    <!-- Date_of_birth -->
        <div class="form-group">

        </div>

                    <!-- Email -->
        <div class="form-group">

        </div>
                    <!-- Phone -->
        <div class="form-group">

        </div>

                    <!-- Password -->
        <div class="form-group">

        </div>

                    <!-- Sex_id (Foránea) -->
        <div class="form-group">

        </div>
                    <!-- User_status_id (Foránea) -->
        <div class="form-group">

        </div>

                    <!-- Role_id (Foránea) -->
        <div class="form-group">

        </div>

                    <!-- Created_at -->
        <div class="form-group">

        </div>
                    <!-- Updated_at -->
        <div class="form-group">

        </div>

    </div>

    <!-- :::::::::::::::::::::FORM FOOTER:::::::::::::::::::::: -->
    <div class="form-group modal-footer">
        <button type="submit" class="btn btn-info" name="caller_form" value="add_user_form">Agregar</button>
        <button type="reset" class="btn btn-default" data-dismiss="modal">Cancelar</button>
    </div>
</form>
