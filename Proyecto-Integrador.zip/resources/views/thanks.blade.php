@extends("recursos/template_main")


@section("titulo")
    Dèco Enfant - Gracias por su compra
@endsection


@section("principal")
    <h1>Muchas gracias por su compra</h1>
      <a href="/history"> Ver historial de compra</a>
@endsection
