<html>
    <head></head>
    <script src="js/buscarProd.js"></script>
    <body>
      <h1>Buscar Productos</h1>
        <form class="buscador" action="">
            <input type="text" class="buscar">
            <button>Buscar</button>
        </form>
        <ul class="resultados"></ul>
    </body>
</html>
