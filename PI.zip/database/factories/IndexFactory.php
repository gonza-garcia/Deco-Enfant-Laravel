<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Index;
use Faker\Generator as Faker;

$factory->define(Index::class, function (Faker $faker) {
    return [
        //
    ];
});
