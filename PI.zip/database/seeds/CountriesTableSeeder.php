<?php

use Illuminate\Database\Seeder;

class CountriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //no es necesario este seeder, ya que ProvincesTableSeeder también crea los países en la base de datos
    }
}
