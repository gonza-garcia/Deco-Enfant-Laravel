<?php $__env->startSection("titulo"); ?>
    Dèco Enfant - Gracias por su compra
<?php $__env->stopSection(); ?>


<?php $__env->startSection("principal"); ?>


<div class="container">
<div class="jumbotron bg-transparent border text-center text-muted">
    <h1 class="display-6">Muchas gracias por tu compra! <i class="far fa-thumbs-up"></i></h1>
    <hr class="my-4">
    <p>Te enviamos un correo con toda la informacion de tu compra a <?php echo e(Auth::user()->email); ?></p>
    <p class="lead mt-5">
        <a class="btn btn-secondary btn" href="/" role="button">Seguir Navegando en Dèco Enfant</a>
    </p>
</div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/thanks.blade.php ENDPATH**/ ?>