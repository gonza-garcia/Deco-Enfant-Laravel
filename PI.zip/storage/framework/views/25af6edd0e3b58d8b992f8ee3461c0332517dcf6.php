<?php $__env->startSection("titulo"); ?>
    Dèco Enfant - Historial de compras
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" href="/css/style_cart.css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection("principal"); ?>


<div class="container">
  <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <p class="text-dark m-0">Codigo de compra: <span class="text-muted"> <?php echo e($cart->first()->cart_number); ?></span></p>
  <p class="text-dark my-1">Enviado el: <span class="text-muted"> <?php echo e($cart->first()->updated_at); ?> </span></p>
  
  
  <div class="row mb-5">
    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="card-deck my-2 h-100">
        <div class="card">
          <img class="card-img-top" src="<?php echo e(url($items->thumbnail)); ?>" alt=<?php echo e($items->name); ?>>
          <div class="card-body">
            <h6 class="card-title"><?php echo e($items->name); ?></h6>
            <p class="card-text"><small><?php echo e($items->short_desc); ?></small></p>
          </div>
          <div class="card-footer btn">
            <a href="/producto/<?php echo e($items->id); ?>" class="d-block text-decoration-none"><small class="text-muted">Volver a comprar</small></a> 
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  
  
  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <p>Su historial de compra está vacío</p>
  <?php endif; ?>
  
</div>

<?php $__env->stopSection(); ?>




  
  
      
      
        
        





<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/history.blade.php ENDPATH**/ ?>