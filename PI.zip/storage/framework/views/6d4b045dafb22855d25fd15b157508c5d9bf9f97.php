<form id='edit_products_form' action='/producto/edit/' method="POST" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
    <!-- ::::::::::::::::::::::FORM HEADER::::::::::::::::::::: -->
    <div class="modal-header">
        <h4 class="modal-title">Editar Producto</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    </div>

    <!-- ::::::::::::::::::::::FORM BODY::::::::::::::::::::::: -->
    <div class="modal-body">
                    <!-- Id (No editable) -->
        <div class="form-group">
            <label class='mb-0 text-right justify-content-end' for='id'>Id</label>
            <label class="campo_no_editable form-control w-100 text-right"></label>
        </div>

                    <!-- Name -->
        <div class="form-group">
            <label class='mb-0 text-right justify-content-end' for='name'>Nombre</label>
            <input type='text' name='name' value="" class='campo_editable form-control w-100 text-right'>
        </div>

                    <!-- Short_desc -->
        <div class="form-group">
            <label class='mb-0 text-right justify-content-end' for='short_desc'>Descripción Corta</label>
            <input type='text' name='short_desc' value="" class='campo_editable form-control w-100 text-right'>
        </div>

                    <!-- Long_desc -->
        <div class="form-group">
            <label class='mb-0 text-right justify-content-end' for='long_desc'>Descripción Larga</label>
            <input type='text' name='long_desc' value="" class='campo_editable form-control w-100 text-right'>
        </div>

                    <!-- Price -->
        <div class="form-group">
            <label class='mb-0 text-right justify-content-end' for='price'>Precio</label>
            <input type='text' name='price' value="" class='campo_editable form-control w-100 text-right'>
        </div>

                    <!-- Thumbnail -->
        <div class="form-group">
          <label class="mb-0 text-right justify-content-end" for="images">Imagen: </label>
          <input class="form-control w-100 text-right" id="browseForEdit" type="file" name="thumbnail" value="" onchange="previewFileForEdit()" multiple><br>
          <div><img id='previewForEdit' class="img-fluid" src="" height="200" alt="Image preview..."></div>
        </div>

                    <!-- Stock -->
        <div class="form-group">
            <label class='mb-0 text-right justify-content-end' for='stock'>Stock</label>
            <input type='text' name='stock' value="" class='campo_editable form-control w-100 text-right'>
        </div>

                    <!-- Discount -->
        <div class="form-group">
            <label class='mb-0 text-right justify-content-end' for='discount'>Descuento</label>
            <input type='text' name='discount' value="" class='campo_editable form-control w-100 text-right'>
        </div>

                <!-- Color_id  (Foránea)-->
        <div class="form-group">
            <label class='mb-0 text-right justify-content-end' for='color_id'>Color</label>
            <select class="campo_editable form-control w-100" id='color_id' name='color_id' value="">
                <?php $__currentLoopData = $all_colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($color->id); ?>

                        <?php if($color->id == $product->color_id): ?> <?php echo e('selected'); ?> <?php endif; ?>>
                        <?php echo e($color->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

                    <!-- Size_id  (Foránea)-->
        <div class="form-group">
            <label class='mb-0 text-right justify-content-end' for='size_id'>Color</label>
            <select class="campo_editable form-control w-100" id='size_id' name='size_id' value="" >
                <?php $__currentLoopData = $all_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($size->id); ?>

                        <?php if($size->id == $product->size_id): ?> <?php echo e('selected'); ?> <?php endif; ?>>
                        <?php echo e($size->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

                    <!-- Subcategoría-->
        <div class="form-group">
            <label class='mb-0 text-right justify-content-end' for='subcategory_id'>Subcategoría</label>
            <select class="campo_editable form-control w-100" id='subcategory_id' name='subcategory_id' value="" >
                <?php $__currentLoopData = $all_subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($subcat->id); ?>

                        <?php if($subcat->id == $product->subcategory_id): ?> <?php echo e('selected'); ?> <?php endif; ?>>
                        <?php echo e($subcat->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


    </div>

    <!-- :::::::::::::::::::::FORM FOOTER:::::::::::::::::::::: -->
    <div class="form-group modal-footer">
        <button type="submit" class="btn btn-info" name="caller_form" value="edit_product_form">Editar</button>
        <button type="reset" class="btn btn-default" data-dismiss="modal">Cancelar</button>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/recursos/formularios/edit_products_form.blade.php ENDPATH**/ ?>