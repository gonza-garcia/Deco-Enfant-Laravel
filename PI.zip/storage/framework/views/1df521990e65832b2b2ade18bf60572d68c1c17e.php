<?php $__env->startSection("titulo"); ?>
    Dèco Enfant - Categorias
<?php $__env->stopSection(); ?>


<?php $__env->startSection("principal"); ?>

  <section class="container">

      <h3>Categorias</h3>
      <div class="row px-2">


        <ul>

          <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="/categoria/<?php echo e($category->id); ?>">
              <li><?php echo e($category->name); ?></li>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            No hay Categorias
          <?php endif; ?>

          </ul>
      </div>

  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/categories.blade.php ENDPATH**/ ?>