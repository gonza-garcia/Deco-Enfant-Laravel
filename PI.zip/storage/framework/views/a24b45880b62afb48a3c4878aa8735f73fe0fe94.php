<?php $__env->startSection("titulo"); ?>
    Dèco Enfant - Gracias por su compra
<?php $__env->stopSection(); ?>


<?php $__env->startSection("principal"); ?>


<div class="container">
<div class="jumbotron bg-transparent border text-center text-muted">
    <h1 class="display-6">Muchas gracias por tu compra! <i class="far fa-thumbs-up"></i></h1>
    <p class="lead">Orden n°: <?php echo e($order->cart_number); ?></p>
    

    <hr class="my-4">
    <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
    <p class="lead">
        <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
    </p>
</div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views//thanks.blade.php ENDPATH**/ ?>