<?php
    // $stmt-withPath('?order_by='.$_GET[])
?>

<?php $__env->startSection("titulo_objeto"); ?>
    Producto
<?php $__env->stopSection(); ?>


<?php $__env->startSection("table_headers"); ?>
    <!-- Invertir el orden actual para pasarlo como parametro por get cuando se haga click en los links siguientes -->
      <?php if ($order_how=="ASC") $new_order="DESC";
            else                   $new_order="ASC"; ?>

    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(($key == 'updated_at') || ($key=='deleted_at')): ?>
            <?php continue; ?>

        <?php elseif($key=='category_id'): ?>
            <th style="width: <?php echo e($column['width']); ?>;">
                <a href="#">
                    <?php echo e($column['name']); ?>

                </a>
            </th>
            <?php continue; ?>
        <?php endif; ?>

        <th style="width: <?php echo e($column['width']); ?>;">
            <a href="/productos/admin?table=products&order_by=<?php echo e($key); ?>&order_how=<?php echo e($new_order); ?>&limit=<?php echo e($limit); ?>&page=<?php echo e($page); ?>">
                <?php echo e($column['name']); ?>

            </a>
        </th>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection("table_rows"); ?>

    <?php $__currentLoopData = $all_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($product->id); ?>">
  <!-- Celda Checkboxes -->
            <td>
                <span class="custom-checkbox">
                    <input type="checkbox" id="checkbox1" name="options[]" value="1">
                    <label for="checkbox1"></label>
                </span>
            </td>

  <!-- Celda Id -->
            <td> <b><?php echo e($product->id); ?></b> </td>
  <!-- Celda Título -->
            <td> <?php echo e($product->name); ?> </td>
  <!-- Celda Descripción Corta -->
            <td> <?php echo e($product->short_desc); ?> </td>
  <!-- Celda Descripción Larga -->
            <td> <?php echo e($product->long_desc); ?> </td>
  <!-- Celda Precio -->
            <td> <?php echo e($product->price); ?> </td>
  <!-- Celda Imagen -->
            <td> <a href="<?php echo e(url($product->thumbnail)); ?>" class="view" title=<?php echo e($product->thumbnail); ?> data-toggle="tooltip"><i class="material-icons">&#xE417;</i></a></td>
  <!-- Celda Stock -->
            <td> <?php echo e($product->stock); ?> </td>
  <!-- Celda Descuento % -->
            <td> <?php echo e($product->discount); ?> </td>
  <!-- Celda Color -->
            <td> <?php echo e($product->color->name); ?> </td>
  <!-- Celda Tamaño -->
            <td> <?php echo e($product->size->name); ?> </td>
  <!-- Celda Categoría -->
            <td> <?php echo e($product->subcategory->category->name); ?> </td>
  <!-- Celda Sub_Categoría -->
            <td> <?php echo e($product->subcategory->name); ?> </td>
  <!-- Celda Creado -->
            <td> <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $product->created_at)->format('d-m-Y')); ?> </td>

  <!-- Celda Acciones -->
            <td id="acciones">
  	            
                <a id="edit" value="<?php echo e($product->id); ?>" href="#edit_modal" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Editar">&#xE254;</i></a>
                <a href="#delete_modal" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Eliminar">&#xE872;</i></a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection("order_by_select_options"); ?>

    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($key); ?>" <?php if ($order_by==$key) echo 'selected';?>>
            <?php echo e($column['name']); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('pagination'); ?>
  <?php echo e($all_products->links()); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection("add_modal_content"); ?>
    <?php echo $__env->make('recursos/formularios/add_products_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("edit_modal_content"); ?>
    <?php echo $__env->make('recursos/formularios/edit_products_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("delete_modal_content"); ?>
    <?php echo $__env->make('recursos/formularios/delete_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/templates/template_table", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/admin_products.blade.php ENDPATH**/ ?>