<?php $__env->startSection("titulo"); ?>
    Dèco Enfant - <?php echo $__env->yieldContent("titulo_objeto"); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_css'); ?>
    <link rel="stylesheet" href="/css/style_tabla.css">
    <link rel="stylesheet" href="/css/style_modals.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_scripts'); ?>
  <script src="<?php echo e(asset('js/table_scripts.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("principal"); ?>
    <div class="container table-container">
        <div class="table-wrapper">

    <!-- ::::::::::::::::::::::::::FILA DE TITULO::::::::::::::::::::::::::::: -->
    <!-- ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: -->
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
                        <h2>Administrar <b><?php echo $__env->yieldContent("titulo_objeto"); ?></b></h2>
                    </div>
                    <div class="col-sm-6">
                        <a href="#add_modal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Agregar</span></a>
                        <a href="#delete_modal" class="btn btn-danger" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Eliminar</span></a>
                    </div>
                </div>
            </div>

    <!-- :::::::::::::::::::::::::FILA DE FILTROS:::::::::::::::::::::::::::: -->
    <!-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: -->
            <div class="table-filter">
                <div class="row">
                    <div class="col-sm-3">

                    </div>
    <!-- ::::::::::::::::::::::::::::"BUSQUEDA":::::::::::::::::::::::::::: -->
                    <div class="col-sm-9">
                        <div class="filter-group">
                          <div class="search-box">
                              <i class="material-icons">&#xE8B6;</i>
                              <input type="text" class="form-control" placeholder="Buscar&hellip;">
                          </div>
                        </div>

    <!-- ::::::::::::::::::::::::::::"ORDER HOW":::::::::::::::::::::::::::: -->
                        <div class="filter-group">
                            <label>Orden</label>
                            <select class="form-control">
                                <option value="ASC" <?php if($order_how=="ASC"): ?> <?php echo e('selected'); ?><?php endif; ?>>
                                        Ascendente
                                </option>
                                <option value="DESC" <?php if($order_how=="DESC"): ?> <?php echo e('selected'); ?><?php endif; ?>>
                                        Descendente
                                </option>
                            </select>
                        </div>

    <!-- :::::::::::::::::::::::::::::"ORDER BY":::::::::::::::::::::::::::: -->
                        <div class="filter-group">
                            <label>Ordenar por</label>
                            <select class="form-control" name="order_by">
                              <!-- Traer las <option> para el select segun el objeto (products, users, etc):::: -->
                                <?php echo $__env->yieldContent("order_by_select_options"); ?>
                            </select>
                        </div>
                        <span class="filter-icon"><i class="fa fa-filter"></i></span>
                    </div>
                </div>
            </div>

    <!-- :::::::::::::::::::::::::HEADERS DE TABLA:::::::::::::::::::::::::::: -->
    <!-- ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: -->
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
            <!-- Header Checkboxes:::: -->
                        <th style="width: 2.50%;">
                            <span class="custom-checkbox">
                                <input type="checkbox" id="selectAll">
                                <label for="selectAll"></label>
                            </span>
                        </th>
            <!-- Traer los headers segun el objeto (products, users, etc):::: -->
                        <?php echo $__env->yieldContent("table_headers"); ?>

            <!-- Header Acciones -->
                        <th style="width: 5.00%;">Acciones</th>
                    </tr>
                </thead>


    <!-- ::::::::::::::::::::::::::FILAS DE TABLA:::::::::::::::::::::::::::::: -->
    <!-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: -->
                <tbody>
            <!-- Traer todas las filas segun el objeto (products, users, etc):::: -->
                    <?php echo $__env->yieldContent("table_rows"); ?>

                </tbody>
            </table>

    <!-- :::::::::::::::::::::::::::PIE DE TABLA:::::::::::::::::::::::::::: -->
    <!-- ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: -->
            <div class="table-footer">
    <!-- ::::::::::::::::::::::::::::::MOSTRANDO:::::::::::::::::::::::::::: -->
                <div class="show-entries">
                    <span>Mostrando</span>
                    <select class="p-0">
                        <?php $__currentLoopData = $limit_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($value); ?> <?php if($value==$limit): ?> <?php echo e('selected'); ?> <?php endif; ?>>
                                    <?php echo e($value); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span>de <b><?php echo e($total_rows); ?></b> entradas</span>
                </div>

    <!-- :::::::::::::::::::::::::::PAGINACIÓN:::::::::::::::::::::::::::::: -->
                <ul class="pagination">
                    <?php echo $__env->yieldContent('pagination'); ?>
                </ul>
            </div>
        </div>
    <!-- :::::::::::::::::::::::::::FIN DE TABLA:::::::::::::::::::::::::::::: -->
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("modals"); ?>

  <!-- :::::::::::::::::::::::::::::::: ADD Modal HTML ::::::::::::::::::::::::::::::::::::-->
  <!-- ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::-->
  <div id="add_modal" class="modal fade">
      <div class="modal-dialog">
          <div class="modal-content">

              <?php echo $__env->yieldContent('add_modal_content'); ?>

          </div>
      </div>
  </div>

  <!-- :::::::::::::::::::::::::::::::: EDIT Modal HTML :::::::::::::::::::::::::::::::::::-->
  <!-- ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::-->
  <div class="container">
      <div id="edit_modal" class="modal fade">
          <div class="modal-dialog">
              <div class="modal-content">

              <?php echo $__env->yieldContent('edit_modal_content'); ?>

              </div>
          </div>
      </div>
  </div>

  <!-- :::::::::::::::::::::::::::::::: DELETE Modal HTML :::::::::::::::::::::::::::::::::-->
  <!-- ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::-->
  <div id="delete_modal" class="modal fade">
      <div class="modal-dialog">
          <div class="modal-content">

              <?php echo $__env->yieldContent('delete_modal_content'); ?>

          </div>
      </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/recursos/templates/template_table.blade.php ENDPATH**/ ?>