<?php $__env->startSection('custom_css'); ?>

<link rel="stylesheet" type="text/css" href="\slick\slick-theme.scss"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script src="/js/slick.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("titulo"); ?>
Dèco Enfant - slick
<?php $__env->stopSection(); ?>



<?php $__env->startSection("principal"); ?>         



<div class="slider slider-for slick-initialized slick-slider">
    <div class="slick-list draggable">
        <div class="slick-track">
                <div class='slick-slide slick-current slick-active'><img src=".\img\products\alfo_001.jpg" alt=""></div>
                <div class='slick-slide'><img src=".\img\products\alfo_002.jpg" alt=""></div>
                <div class='slick-slide'><img src=".\img\products\almo.jpg" alt=""></div>
        </div>    
    </div>
</div>

<div class="slider slider-nav slick-initialized slick-slider slick-dotted">
    <div class="slick-list draggable">
        <div class="slick-track">
                <div><img src=".\img\products\alfo_001.jpg" alt=""></div>
                <div><img src=".\img\products\alfo_002.jpg" alt=""></div>
                <div><img src=".\img\products\almo.jpg" alt=""></div>
        </div>

    </div>

</div>





    
<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views//probandoslick.blade.php ENDPATH**/ ?>