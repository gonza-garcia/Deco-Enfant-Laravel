<?php $__env->startSection("titulo"); ?>
Dèco Enfant - Detalle del carrito
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" href="/css/style_cart.css">
<?php $__env->stopSection(); ?>

  
  <?php $__env->startSection("principal"); ?>
  
  <section class="container">
    
      
      <div class="container">
        <div class="historial float-right mb-2">
            <a href="/history" class="btn btn-secondary">Ver historial de compras <i class="far fa-list-alt"></i></a>
        </div>
        <table id="cart" class="table table-hover">
          <thead class="cart-thead text-left">
            <tr>
              <th style="width:45%">Producto</th>
              <th style="width:15%">Precio x Unid.</th>
              <th style="width:15%">Cantidad</th>
              <th style="width:15%" class="text-center">Subtotal</th>
              <th style="width:10%"></th>
            </tr>
          </thead>
          <?php $__empty_1 = true; $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tbody>
            <tr>
              <td data-th="Producto">
                <div class="row">
                  <div class="col-sm-3 d-sm-block"><img src="<?php echo e($items->thumbnail); ?>" alt=<?php echo e($items->name); ?> class="img-fluid img-thumbnail"/></div>
                  <div class="col-sm-9">
                    <h5 class="m-0"><?php echo e($items->name); ?></h5>
                    <p class="font-italic my-0"><?php echo e($items->short_desc); ?></p>
                    <p class="font-italic my-0"><?php echo e($items->size->name); ?></p>
                  </div>
                </div>
              </td>
              <?php if($items->discount > 25): ?>
              <td data-th="Precio" class="text-danger">$ <?php echo e((number_format($items->price - ($items->discount/100*$items->price),2, ',', ''))); ?></td>
              <?php else: ?>
              <td data-th="Precio">$ <?php echo e((number_format($items->price, 2, ',', ''))); ?></td>
              <?php endif; ?>
              
              <td data-th="Cantidad">
                <form class="input-group" action="/cart/update/<?php echo e($items->id); ?>" method="post">
                  <?php echo e(csrf_field()); ?>     
                  <?php echo e(method_field('PUT')); ?>

                  <input type="hidden" name="prodId" value=<?php echo e($items->id); ?>>
                  <input type="number" name="cant" class="form-control" value=<?php echo e($items->cant); ?> min="1" max=<?php echo e($items->stock); ?>>   
                  <button class="btn btn-sm ml-1" type="submit" value=""><i class="fas fa-sync-alt"></i></button>                  
                </form>
                
              </td>
              <?php if($items->discount > 25): ?>
              <td data-th="Subtotal" class="text-center"> $ <?php echo e((number_format( ($items->price - ($items->discount / 100 * $items->price) ) * $items->cant , 2, ',', ''))); ?></td>
              <?php else: ?>
              <td data-th="Subtotal" class="text-center"> $ <?php echo e((number_format($items->price * $items->cant , 2, ',', ''))); ?></td>
              <?php endif; ?>

              <td class="actions" data-th="">
                <form class="text-center" action="/cart/<?php echo e($items->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></button>
                </form>              
              </td>
            </tr>
          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p>Su carrito esta vacio</p>
          <?php endif; ?>
          
          <tfoot>
            <tr class="d-sm-none">
              <td class="text-center"><strong> Total $ <?php echo e((number_format($totalPrice , 2, ',', ''))); ?></strong></td>
            </tr>
            <tr>
              <td><a href="/productos" class="btn btn-seguir"><i class="fa fa-angle-left"></i> Seguir Comprando</a></td>
              <td colspan="2" class="hidden-xs"></td>
              <td class="d-none d-sm-block text-center"><strong> Total $ <?php echo e((number_format($totalPrice, 2, ',', ''))); ?></strong></td>
              
              <td class="px-0">
                <?php if($cart->isNotEmpty()): ?>
                <a href="/cart/close" class="btn btn-comprar btn-block">Comprar <i class="fa fa-angle-right"></i></a>
                <?php endif; ?>
              </td>  
            </tr>
          </tfoot>
          
        </table>
      </div>
    </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views//cart.blade.php ENDPATH**/ ?>