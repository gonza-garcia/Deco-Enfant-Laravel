<?php $__env->startSection("titulo"); ?>
    Dèco Enfant - Estados de usuario
<?php $__env->stopSection(); ?>

<?php $__env->startSection("principal"); ?>
  <section class="container">
      <h3>Estados de usuario</h3>
      <div class="row px-2">
        <ul>
          <?php $__empty_1 = true; $__currentLoopData = $user_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="/userStatus/<?php echo e($user_status->id); ?>">
              <li><?php echo e($user_status->name); ?></li>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            No hay estaods de usuarios
          <?php endif; ?>
          </ul>
      </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("recursos/template_main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital_House\dh_proyecto_integrador_laravel4\Proyecto-Integrador\resources\views/user_statuses.blade.php ENDPATH**/ ?>